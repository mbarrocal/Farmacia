package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.DAO;

import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField txtLogin;
	private JPasswordField txtSenha;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame. construtor
	 */
	public Login() {
		addWindowListener(new WindowAdapter() {	
			@Override
			public void windowActivated(WindowEvent e) {
				// evento disparado quando a janela e ativada
				status();
			}
		});
		setIconImage(Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/img/pc.png")));
		setTitle("infoX-Login");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 635, 394);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Login");
		lblNewLabel.setBounds(146, 241, 46, 14);
		contentPane.add(lblNewLabel);

		txtLogin = new JTextField();
		txtLogin.setBounds(202, 238, 220, 20);
		contentPane.add(txtLogin);
		txtLogin.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("Senha");
		lblNewLabel_1.setBounds(146, 272, 46, 14);
		contentPane.add(lblNewLabel_1);

		txtSenha = new JPasswordField();
		txtSenha.setBounds(202, 269, 220, 20);
		contentPane.add(txtSenha);

		JButton btnEntrar = new JButton("Entrar");
		btnEntrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				logar();
			}
		});
		btnEntrar.setBounds(274, 300, 89, 23);
		contentPane.add(btnEntrar);

		textField_1 = new JTextField();
		textField_1.setText("");
		textField_1.setBounds(202, 238, 220, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);

		lblStatus = new JLabel("");
		lblStatus.setIcon(new ImageIcon(Login.class.getResource("/img/dberror.png")));
		lblStatus.setBounds(539, 291, 32, 32);
		contentPane.add(lblStatus);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon(Login.class.getResource("/imgg/drus.png")));
		lblNewLabel_2.setBounds(241, 91, 134, 136);
		contentPane.add(lblNewLabel_2);
	} // fim do construtor

	// Criar um objeto para conectar com o banco de dados

	DAO dao = new DAO();
	private JLabel lblStatus;

	// Status da conexao
	private void status() {
		try {
			// Estabelecer a conexao com o banco
			Connection con = dao.conectar();
			// Status da conexao
			if (con == null) {
				// imprimir a mensagem no console
				System.out.println("Erro de conex�o");
				// trocar o icone
				lblStatus.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/dberror.png")));
			} else {
				System.out.println("Conex�o estabelecida com sucesso");
				// exibir o icone
				lblStatus.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/dbok.png")));
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	// login no sistema
	private void logar() {
		// validacao de campos obrigatorios
		if (txtLogin.getText().isEmpty()) {
			// caixa de mensagem
			JOptionPane.showMessageDialog(null, "Preencha o nome do usu�rio");
			// posicionar o cursor na caixa de texto do usuario
			txtLogin.requestFocus();
		} else {
			// logica principal do login
			try {
					// query (comando sql)
				String read= "select * from usuarios where login=? and senha=md5(?)";
				// abrir a conexao
				Connection con = dao.conectar();
				// Uso do PrepareStatement(JDBC) para substituir as ? pelo conteudo das caixas
				// de texto
				PreparedStatement pst = con.prepareStatement(read);
				// substituir as ? pelo conteudo das caixas de texto
				pst.setString(1, txtLogin.getText());
				pst.setString(2, txtSenha.getText());
				// Uso do reSet para obter os dados do banco
				ResultSet rs = pst.executeQuery();
				//se existir usuario cadastrado com login e senha
				if (rs.next()) {
				//ativar a tela principal
				Principal principal = new Principal();
				principal.setVisible(true);
				this.dispose(); //fechar a tela de login
				} else {
				JOptionPane.showMessageDialog(null, "login e/ou senha inv�lido(s)");
				}
				con.close(); //encerrar a conexao		
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}
}
