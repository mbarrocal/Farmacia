package view;

import java.awt.EventQueue;

import javax.swing.JDialog;
import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

public class Sobre extends JDialog {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Sobre dialog = new Sobre();
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the dialog.
	 */
	public Sobre() {
		setModal(true);
		setResizable(false);
		setTitle("infoX - Sobre");
		setIconImage(Toolkit.getDefaultToolkit().getImage(Sobre.class.getResource("/img/pc.png")));
		setBounds(100, 100, 398, 265);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Projeto Integrador");
		lblNewLabel.setBounds(129, 34, 115, 14);
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Matheus Barrocal");
		lblNewLabel_1.setBounds(129, 66, 211, 14);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("New label");
		lblNewLabel_2.setIcon(new ImageIcon(Sobre.class.getResource("/imgg/certified.png")));
		lblNewLabel_2.setBounds(143, 91, 64, 64);
		getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Vers\u00E3o 1.0");
		lblNewLabel_3.setBounds(22, 201, 64, 14);
		getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Sob a licen\u00E7a GPL");
		lblNewLabel_4.setBounds(264, 201, 102, 14);
		getContentPane().add(lblNewLabel_4);

	}

	
}
