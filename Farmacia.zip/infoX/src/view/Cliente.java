package view;

import java.awt.EventQueue;

import javax.swing.JDialog;
import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import model.DAO;
import net.proteanit.sql.DbUtils;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JDesktopPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.SystemColor;
import java.awt.Color;

public class Cliente extends JDialog {
	private JTextField txtIdCli;
	private JTextField txtFoneCli;
	private JTextField txtCliente;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cliente dialog = new Cliente();
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the dialog.
	 */
	public Cliente() {
		getContentPane().setBackground(Color.GRAY);
		setBackground(SystemColor.desktop);
		setTitle("infoX - Clientes");
		setIconImage(Toolkit.getDefaultToolkit().getImage(Cliente.class.getResource("/img/pc.png")));
		setResizable(false);
		setModal(true);
		setBounds(100, 100, 642, 434);
		getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("ID");
		lblNewLabel.setBounds(10, 251, 46, 14);
		getContentPane().add(lblNewLabel);

		txtIdCli = new JTextField();
		txtIdCli.setEnabled(false);
		txtIdCli.setBounds(66, 245, 86, 20);
		getContentPane().add(txtIdCli);
		txtIdCli.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("Nome");
		lblNewLabel_1.setBounds(10, 276, 46, 14);
		getContentPane().add(lblNewLabel_1);

		txtCliente = new JTextField();
		txtCliente.setText("");
		txtCliente.setBounds(66, 273, 261, 20);
		getContentPane().add(txtCliente);
		txtCliente.setColumns(10);

		JLabel lblNewLabel_2 = new JLabel("Fone");
		lblNewLabel_2.setBounds(361, 246, 46, 14);
		getContentPane().add(lblNewLabel_2);

		txtFoneCli = new JTextField();
		txtFoneCli.setBounds(417, 243, 129, 20);
		getContentPane().add(txtFoneCli);
		txtFoneCli.setColumns(10);

		btnAdicionarCliente = new JButton("");
		btnAdicionarCliente.setToolTipText("Adicionar Cliente");
		btnAdicionarCliente.setIcon(new ImageIcon(Cliente.class.getResource("/imgg/add.png")));
		btnAdicionarCliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				adicionarCliente();
			}
		});
		btnAdicionarCliente.setBounds(60, 304, 80, 80);
		getContentPane().add(btnAdicionarCliente);

		txtPesquisar = new JTextField();
		txtPesquisar.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				// evento digitar na caixa de texto
				pesquisarCliente();
			}
		});
		txtPesquisar.setBounds(51, 27, 212, 20);
		getContentPane().add(txtPesquisar);
		txtPesquisar.setColumns(10);

		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(Cliente.class.getResource("/imgg/lupa 24.png")));
		lblNewLabel_3.setBounds(273, 15, 32, 32);
		getContentPane().add(lblNewLabel_3);

		JDesktopPane desktopPane = new JDesktopPane();
		desktopPane.setBounds(10, 70, 586, 150);
		getContentPane().add(desktopPane);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 589, 151);
		desktopPane.add(scrollPane);

		tableCliente = new JTable();
		tableCliente.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// setar os campos da tabela
				setarCampos();
			}
		});
		scrollPane.setViewportView(tableCliente);

		btnEditarCliente = new JButton("");
		btnEditarCliente.setEnabled(false);
		btnEditarCliente.setToolTipText("Editar Cliente");
		btnEditarCliente.setIcon(new ImageIcon(Cliente.class.getResource("/imgg/pena.png")));
		btnEditarCliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				editarCliente();

			}

		});
		btnEditarCliente.setBounds(261, 304, 80, 80);
		getContentPane().add(btnEditarCliente);

		btnExcluirCliente = new JButton("");
		btnExcluirCliente.setEnabled(false);
		btnExcluirCliente.setToolTipText("Excluir Cliente");
		btnExcluirCliente.setIcon(new ImageIcon(Cliente.class.getResource("/imgg/delete2.png")));
		btnExcluirCliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				excluirCliente();
			}

		});
		btnExcluirCliente.setBounds(453, 304, 80, 80);
		getContentPane().add(btnExcluirCliente);

	}// fim do construtor

	// criar objeto para reutilizar a classe DAO (conexao com o banco)
	DAO dao = new DAO();
	private JTextField txtPesquisar;
	private JTable tableCliente;
	private JButton btnEditarCliente;
	private JButton btnExcluirCliente;
	private JButton btnAdicionarCliente;

	// metodo para inserir um novo cliente
	private void adicionarCliente() {
		// validacao dos campos obrigatorios
		if (txtCliente.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "preencha o nome do cliente ");
			txtCliente.requestFocus();
		} else if (txtFoneCli.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o fone do cliente ");
			txtFoneCli.requestFocus();

		} else {
			// logica principal
			// String (query) SQL
			String create = "insert into clientes (nome,fone) values (?,?)";
			try {
				// estabelecer uma conexao atraves da classe DAO
				Connection con = dao.conectar();
				// preparar a conexao com a instru��o sql (query)
				PreparedStatement pst = con.prepareStatement(create);
				// substituir parametros (?) pelo conteudo das caixas de texto

				pst.setString(1, txtCliente.getText());
				pst.setString(2, txtFoneCli.getText());

				// executar a query confirmando a inclusao do cliente
				int confirma = pst.executeUpdate();
				if (confirma == 1) {
					JOptionPane.showMessageDialog(null, "Cliente adicionado com sucesso.");

				}
				// encerrar a conexao
				con.close();
				// limpar os campos
				limpar();
			} catch (Exception e) {
				System.out.println(e);

			}
		}
	}

	// editar usuario (CRUD Update)
	private void editarCliente() {
		// validacao
		if (txtCliente.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o Cliente");
			txtCliente.requestFocus();
		} else if (txtFoneCli.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o FoneCli");
			txtFoneCli.requestFocus();
		} else {
			// instrucao sql para editar um cliente
			String update = "update clientes set nome=?,fone=? where idcli=?";
			try {
				// estabelecer uma conexao atraves da classe DAO
				Connection con = dao.conectar();
				// preparar a instru��o sql
				PreparedStatement pst = con.prepareStatement(update);
				// substituir parametros (?)
				pst.setString(1, txtCliente.getText());
				pst.setString(2, txtFoneCli.getText());
				pst.setString(3, txtIdCli.getText());
				
				// exibir um caixa de mensagem caso o cliente seja editado
				int confirma = pst.executeUpdate();
				if (confirma == 1) {
					JOptionPane.showMessageDialog(null, "Dados do cliente alterados com sucesso");
				}
				limpar();
				con.close();

				// encerrar a conexao
				con.close();
				// limpar os campos
				limpar();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}

	// excluir cliente (CRUD Delete)
	private void excluirCliente() {
		// confirmar a exclusao do cliente
		int confirma = JOptionPane.showConfirmDialog(null, "Confirma a exclus�o?", "Aten��o!",
				JOptionPane.YES_NO_OPTION);
		

		if (confirma == JOptionPane.YES_OPTION) {
			// instrucao sql para excluir um cliente
			String delete = "delete from clientes where idcli=?";
			try {
				// estabelecer uma conexao atraves da classe DAO
				Connection con = dao.conectar();
				// preparar a instru��o sql
				PreparedStatement pst = con.prepareStatement(delete);
				// substituir parametros (?)
				pst.setString(1, txtIdCli.getText());
				// exibir um caixa de mensagem caso o cliente seja excluido
				int verifica = pst.executeUpdate();
				if (verifica == 1) {
					JOptionPane.showMessageDialog(null, "Cliente exclu�do com sucesso");
					
					
				
				}
				limpar();
				con.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}

	
	
	// pesquisa avancada de clientes usando a biblioteca rs2xml
	private void pesquisarCliente() {
		String read = "select * from clientes where nome like ? order by nome";
		try {
			System.out.println("testando o evento");
			// abrir a conexao com o banco
			Connection con = dao.conectar();
			// preparar a query (instrucao sql) para pesquisar no banco
			PreparedStatement pst = con.prepareStatement(read);
			// substituir o paramentro (?) Atencao ao % para completar a query
			pst.setString(1, txtPesquisar.getText() + "%");
			// obter os dados do banco (resultado)
			ResultSet rs = pst.executeQuery();
			// popular(preencher) a tabela com os dados do banco
			tableCliente.setModel(DbUtils.resultSetToTableModel(rs));

		} catch (Exception e) {
			System.out.println(e);
		}

	}

	// setar os campos do formulario com o conteudo da tabela
	private void setarCampos() {
	int setar = tableCliente.getSelectedRow();
	// (setar, 0) 0 -> primeiro campo da tabela
	// 1 -> segundo campo da tabela e assim sucessivamente
	txtIdCli.setText(tableCliente.getModel().getValueAt(setar, 0).toString());
	txtCliente.setText(tableCliente.getModel().getValueAt(setar, 1).toString());
	txtFoneCli.setText(tableCliente.getModel().getValueAt(setar, 2).toString());
	btnEditarCliente.setEnabled(true);
	btnExcluirCliente.setEnabled(true);
	btnAdicionarCliente.setEnabled(false);
	}
		
		
		
	

	// limpar campos e gerenciar os botoes
	private void limpar() {
	// limpar as caixas de texto
	txtCliente.setText(null);
	txtFoneCli.setText(null);
	txtPesquisar.setText(null);
	btnAdicionarCliente.setEnabled(true);
	btnEditarCliente.setEnabled(false);
	btnExcluirCliente.setEnabled(false);

	}
	
		
		}
	

